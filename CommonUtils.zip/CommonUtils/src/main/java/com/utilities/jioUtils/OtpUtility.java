package com.utilities.jioUtils;

import com.utilities.connectionUtils.DataBaseUtility;
import java.sql.ResultSet;

/**
 * @author Hemanth.Vanapalli on 17-01-2020
 */

public class OtpUtility {

    /**
     * This method will generate OTP from IDAM Database
     *
     * @param number - Mobile Number
     * @param env    - Environment {"SIT"} or {"PP"}
     * @return
     */
    public static String idamOTP(String number, String env) {

        String mobileOTP;
        String query = "select time_stamp, TRANSACTIONID, EXTRACTVALUE(xmltype(transaction),'//*[local-name()=\"Value\"]') as OTP from log\n" +
                "where interfaceID='JMIDAMSNotificationServices' and transactionid like'%OTP_+91" + number + "%' and transactiontype='Received'\n" +
                "order by time_stamp desc";

        if (env.toUpperCase().equalsIgnoreCase("SIT"))
            DataBaseUtility.createOracleDatabaseConnection("10.140.139.110", "1521", "tiborc", "tibcocle", "tibcocle");
        else
            DataBaseUtility.createOracleDatabaseConnection("10.143.58.34", "1521", "tiborc", "tibcocle", "tibcocle");

        ResultSet resultSet = DataBaseUtility.executeSelectStatement(query);

        try {
            if (resultSet != null && resultSet.next())
                mobileOTP = resultSet.getString("OTP");
            else
                throw new AssertionError("OTP not present in IDAM Database");

            resultSet.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return mobileOTP;
    }
}
