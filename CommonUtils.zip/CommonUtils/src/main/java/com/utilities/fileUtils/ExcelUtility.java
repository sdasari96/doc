package com.utilities.fileUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.*;

import com.utilities.javaUtils.DateUtility;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * @author Hemanth.Vanapalli on 17-01-2020
 */

public class ExcelUtility {


    public static Map<String, Integer> MapColumnIndex = new HashMap<>();
    public static List<Map<String, String>> excelDataSet = new ArrayList<>();

    /**
     * Method to get the column index of Excel Sheet
     *
     * @created by Shashank
     * @modified by Hemanth on 17-01-2020
     */
    public static void getColumnIndex(XSSFSheet sheet) {
        /*try {*/
            // get first row of the sheet
            XSSFRow row = sheet.getRow(0);

            int minColumnIndex = row.getFirstCellNum();
            int maxCoulmnIndex = row.getLastCellNum();

            // store the column value and its value in hash-map
            for (int i = minColumnIndex; i < maxCoulmnIndex; i++) {

                XSSFCell cell = row.getCell(i);
                System.out.println("index: "+i+" : "+cell.getStringCellValue());
                MapColumnIndex.put(cell.getStringCellValue(), cell.getColumnIndex());
            }
        /*} catch (Exception e) {
            throw new RuntimeException(
                    "ExcelUtility : get_column_index || Error while getting the column index.\n" + e.getMessage(), e);
        }*/
    }

    /**
     * @param sheet
     * @return Column Index
     * @created by Shashank
     * @modified by Hemanth on 17-01-2020
     * <p>
     * This method returns the column index value
     */

    public static Map<String, Integer> getExcelColumnIndex(XSSFSheet sheet) {
        Map<String, Integer> MapColumnIndex = new HashMap<>();
        try {
            // get first row of the sheet
            XSSFRow row = sheet.getRow(0);

            int minColumnIndex = row.getFirstCellNum();
            int maxCoulmnIndex = row.getLastCellNum();

            // store the column value and its value in hash-map
            for (int i = minColumnIndex; i < maxCoulmnIndex; i++) {
                XSSFCell cell = row.getCell(i);
                MapColumnIndex.put(cell.getStringCellValue(), cell.getColumnIndex());
            }
        } catch (Exception e) {
            throw new RuntimeException(
                    "ExcelUtility : get_column_index || Error while getting the column index.\n" + e.getMessage(), e);
        }

        return MapColumnIndex;
    }

    /**
     * @param sheet        - Sheet name
     * @param testCaseName - Test case name
     * @created by Shashank
     * @modified by Hemanth on 17-01-2020
     * <p>
     * You need to execute 'getColumnIndex' method first. On the basis of test
     * case name and execution check, it will return the count of test case
     */

    public static int getTestCaseCount(XSSFSheet sheet, String testCaseName) {
        DataFormatter dataformatter = new DataFormatter();
        int testCaseCount = 0;

        try {
            int testCaseColumnIndex = MapColumnIndex.get("TestCaseName");
            int executionCheckColumnIndex = MapColumnIndex.get("ExecutionCheck");

            Iterator<Row> iterator = sheet.iterator();
            while (iterator.hasNext()) {
                XSSFRow row = (XSSFRow) iterator.next();
                if (dataformatter.formatCellValue(row.getCell(testCaseColumnIndex)).equalsIgnoreCase(testCaseName)
                        && dataformatter.formatCellValue(row.getCell(executionCheckColumnIndex))
                        .equalsIgnoreCase("Y")) {
                    testCaseCount++;
                }
            }

            return testCaseCount;
        } catch (Exception e) {
            throw new RuntimeException(
                    "ExcelUtility : get_test_case_count || Error while getting the test case count.\n" + e.getMessage(),
                    e);
        }
    }

    /**
     * @param sheetPath    - Excel sheet path name
     * @param sheetName    - Excel sheet name
     * @param testcaseName - Testcase name
     * @created by Shashank
     * @modified by Hemanth on 17-01-2020
     * Method to get the data form the Excel. Test Data sheet must contain the
     * Execution check and TestCaseName, on the basis of this method will return the data
     */
    public static Object[][] getDataFromExcel(String sheetPath, String sheetName, String testcaseName) {

        // to format the data in string
        MapColumnIndex.clear();
        DataFormatter dataformatter = new DataFormatter();

        Object[][] obj;
        File file = new File(sheetPath);
        try (InputStream inStream = new FileInputStream(file); XSSFWorkbook workbook = new XSSFWorkbook(inStream);) {

            XSSFSheet sheet = workbook.getSheet(sheetName);

            // to get the column index
            getColumnIndex(sheet);

            int lastRowNum = sheet.getLastRowNum();
            System.out.println(lastRowNum);
            int lastCellNum = sheet.getRow(0).getLastCellNum();

            // get the count of test cases
            int testCaseCount = getTestCaseCount(sheet, testcaseName);

            obj = new Object[testCaseCount][1];
            int arrIndex = 0;

            for (int i = 0; i < lastRowNum; i++) {

                String testName = sheet.getRow(i + 1).getCell(MapColumnIndex.get("TestCaseName")).getStringCellValue();
                String executionCheck = sheet.getRow(i + 1).getCell(MapColumnIndex.get("ExecutionCheck"))
                        .getStringCellValue();

                // getting the values of cell on the basis of test case name and execution check
                if (testName.equalsIgnoreCase(testcaseName) && executionCheck.toUpperCase().equalsIgnoreCase("Y")) {
                    Map<Object, Object> map_data = new HashMap<>();
                    for (int j = 0; j < lastCellNum; j++) {

                        // adding the cell data
                        map_data.put(sheet.getRow(0).getCell(j).toString(),
                                dataformatter.formatCellValue(sheet.getRow(i + 1).getCell(j)));
                    }

                    if (arrIndex < testCaseCount) {

                        // adding the test data in array
                        obj[arrIndex][0] = map_data;
                        System.out.println(obj[arrIndex][0].toString());
                        arrIndex++;
                    } else {
                        break;
                    }
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(
                    "ExcelUtility : get_data_from_excel || Error while reading the Excel file.\n" + e.getMessage(), e);
        }
        System.out.println("Number of TestData present: " + obj.length);
        System.out.println(obj);
        return obj;
    }

    /**
     * This method will read the excel file and returns the workbook
     *
     * @param filePath
     * @return
     * @created by Shashank
     * @modified by Hemanth on 17-01-2020
     */
    public static XSSFWorkbook readExcelFile(String filePath) {
        File file = new File(filePath);
        XSSFWorkbook workbook;
        try (InputStream inStream = new FileInputStream(file)) {
            workbook = new XSSFWorkbook(inStream);
        } catch (Exception e) {
            throw new RuntimeException(
                    "ExcelUtility : get_data_from_excel || Error while reading the Excel file.\n" + e.getMessage(), e);
        }
        return workbook;
    }

    public static List<Map<String, String>> getExcelData(String sheetPath, String sheetName) {
        // to format the data in string
        MapColumnIndex.clear();
        DataFormatter dataformatter = new DataFormatter();

        Object[][] obj;
        File file = new File(sheetPath);
        try (InputStream inStream = new FileInputStream(file); XSSFWorkbook workbook = new XSSFWorkbook(inStream);) {
            XSSFSheet sheet = workbook.getSheet(sheetName);

            // to get the column index
            getColumnIndex(sheet);

            int lastRowNum = sheet.getLastRowNum();
            int lastCellNum = sheet.getRow(0).getLastCellNum();
            //excelDataProvider= new String[lastRowNum][MapColumnIndex.size()];
            for (int i = 1; i <= lastRowNum; i++) {
                XSSFRow row = sheet.getRow(i);
                HashMap<String, String> tempMap = new HashMap<>();

                for (String key : MapColumnIndex.keySet()) {
                    System.out.println(key);

                    String cellValue = null;
                    XSSFCell cell = row.getCell(MapColumnIndex.get(key));
                    if (cell == null)
                        cellValue = "";
                    else {
                        int cellType = cell.getCellType();
                        switch (cellType) {
                            case 0: // numeric
                                if (DateUtil.isCellDateFormatted(cell))
                                    cellValue = String.valueOf(cell.getDateCellValue());
                                else
                                    cellValue = Long.toString(new BigDecimal(String.valueOf(cell.getNumericCellValue())).longValue());
                                break;
                            case 1: // string
                                cellValue = cell.getStringCellValue();
                                break;
                            case 2: // formula
                                cellValue = String.valueOf(cell.getCellFormula());
                                break;
                            case 3: // Blank Cell
                                cellValue = "";
                                break;
                            case 4:// boolean
                                cellValue = String.valueOf(cell.getBooleanCellValue());
                                break;
                            default:
                                System.out.println("invalid cell type: " + cellType);
                                break;
                        }
                    }

                    tempMap.put(key, cellValue);
                    System.out.println("CellValue: "+cellValue+" tempMap size: "+tempMap.size());
                }
                excelDataSet.add(tempMap);
            }
            System.out.println("Excel Data Size: "+excelDataSet.size());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return excelDataSet;
    }

    public static List<Map<String, String>> getExcelDataWithTestCaseName(String sheetPath, String sheetName) {
        // to format the data in string
        MapColumnIndex.clear();
        DataFormatter dataformatter = new DataFormatter();

        Object[][] obj;
        File file = new File(sheetPath);
        try (InputStream inStream = new FileInputStream(file); XSSFWorkbook workbook = new XSSFWorkbook(inStream);)
        {
            XSSFSheet sheet = workbook.getSheet(sheetName);

            // to get the column index
            getColumnIndex(sheet);

            int lastRowNum = sheet.getLastRowNum();
            System.out.println(lastRowNum);
            int lastCellNum = sheet.getRow(0).getLastCellNum();

            // get the count of test cases
            int testCaseCount = getTestCaseCount(sheet, "SRTest");

            obj = new Object[testCaseCount][1];
            int arrIndex = 0;

            for (int i = 1; i < lastRowNum; i++) {

                String testName = sheet.getRow(i).getCell(MapColumnIndex.get("TestCaseName")).getStringCellValue();
                String executionCheck = sheet.getRow(i).getCell(MapColumnIndex.get("ExecutionCheck"))
                        .getStringCellValue();

                // getting the values of cell on the basis of test case name and execution check
                if (testName.equalsIgnoreCase("SRTest") && executionCheck.toUpperCase().equalsIgnoreCase("Y"))
                {
                    XSSFRow row = sheet.getRow(i);
                    HashMap<String, String> tempMap = new HashMap<>();
                    for (String key : MapColumnIndex.keySet()) {
                        System.out.println(key);

                        String cellValue = null;
                        XSSFCell cell = row.getCell(MapColumnIndex.get(key));
                        if (cell == null)
                            cellValue = "";
                        else {
                            int cellType = cell.getCellType();
                            switch (cellType) {
                                case 0: // numeric
                                    if (DateUtil.isCellDateFormatted(cell))
                                        cellValue = String.valueOf(cell.getDateCellValue());
                                    else
                                        cellValue = Long.toString(new BigDecimal(String.valueOf(cell.getNumericCellValue())).longValue());
                                    break;
                                case 1: // string
                                    cellValue = cell.getStringCellValue();
                                    break;
                                case 2: // formula
                                    cellValue = String.valueOf(cell.getCellFormula());
                                    break;
                                case 3: // Blank Cell
                                    cellValue = "";
                                    break;
                                case 4:// boolean
                                    cellValue = String.valueOf(cell.getBooleanCellValue());
                                    break;
                                default:
                                    System.out.println("invalid cell type: " + cellType);
                                    break;
                            }
                        }

                        tempMap.put(key, cellValue);
                        System.out.println("Key: "+key+",CellValue: "+cellValue);
                    }
                    excelDataSet.add(tempMap);
                }
            }



        } catch (Exception e) {
            e.printStackTrace();
        }
        return excelDataSet;
    }


}
