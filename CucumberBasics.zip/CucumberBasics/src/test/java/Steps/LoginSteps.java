package Steps;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

import java.util.List;

public class LoginSteps {
    @Given("^Login with correct username and password$")
    public void loginWithCorrectUsernameAndPassword() {
    }

    @And("^Click on Submit button$")
    public void clickOnSubmitButton() {
    }

    @Then("^I should see the userform page$")
    public void iShouldSeeTheUserformPage() {
    }

    @And("^I enter the following$")
    public void iEnterTheFollowing(DataTable dataTable) {
        /*List<List<String>> data = dataTable.raw();
        System.out.println(data.get(1).get(0));
        System.out.println(data.get(1).get(1));*/

        List<User> user = dataTable.asList(User.class);
        for(User users : user)
        {
            System.out.println("UserName: "+users.username);
            System.out.println(users.password);
        }


    }

    @And("^I enter the ([^\"]*) and ([^\"]*)$")
    public void iEnterTheUsernameAndPassword(String username, String password)
    {
        System.out.println("UserName: "+username);
        System.out.println("Password: "+password);
    }

    public class User
    {
        String username;
        String password;

        public User(String userName, String passWord) {
            username = userName;
            password = passWord;
        }
    }
}
